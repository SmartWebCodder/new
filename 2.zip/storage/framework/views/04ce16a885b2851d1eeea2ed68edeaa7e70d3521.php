<?php
if (Auth('admin')->User()->dashboard_style == "light") {
    $text = "dark";
	$bg = "light";
} else {
	$bg = 'dark';
    $text = "light";
}
?>

    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('admin.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
			<div class="content bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
				<div class="page-inner">
					<div class="mt-2 mb-4">
						<h1 class="title1 text-<?php echo e($text); ?>"><?php echo e($settings->site_name); ?> users list</h1>
					</div>
					
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					<div class="row">
						<div class="col-12">
							<a href="#" data-toggle="modal" data-target="#sendmailModal" class="btn btn-primary btn-lg" style="margin:10px;">Message all</a>
							<?php if($settings->enable_kyc =="yes"): ?>
							<a href="<?php echo e(url('admin/dashboard/kyc')); ?>" class="btn btn-warning btn-lg">KYC</a>
							<?php endif; ?> 
							<a href="#" data-toggle="modal" data-target="#adduser" class="float-right btn btn-primary"> <i class='fas fa-plus-circle'></i> Add User</a>
							<!-- Modal -->
							<div class="modal fade" id="adduser" tabindex="-1" aria-h6ledby="exampleModalh6" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header bg-<?php echo e($bg); ?>">
											<h3 class="mb-2 d-inline text-<?php echo e($text); ?>">Manually Add Users</h3>
											<button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal" aria-h6="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body bg-<?php echo e($bg); ?>">
											<div>
												<form method="POST" action="<?php echo e(route('createuser')); ?>">
													<?php echo csrf_field(); ?>
													<div class="form-row">
														<div class="form-group col-md-12">
															<h6 class="text-<?php echo e($text); ?>">Username</h6>
															<input type="text" id="input1" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="username" required>
														</div>
														<div class="form-group col-md-12">
															<h6 class="text-<?php echo e($text); ?>">Fullname</h6>
															<input type="text" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="name" required>
														</div>
														<div class="form-group col-md-12">
															<h6 class="text-<?php echo e($text); ?>">Email</h6>
															<input type="email" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="email" required>
														</div>
														<div class="form-group col-md-12">
															<h6 class="text-<?php echo e($text); ?>">Password</h6>
															<input type="password" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="password" required>
														</div>
														<div class="form-group col-md-12">
															<h6 class="text-<?php echo e($text); ?>">Confirm Password</h6>
															<input type="password" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="password_confirmation" required>
														</div>
													</div>
													<button type="submit" class="px-4 btn btn-primary">Add User</button>
												</form>  
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="mb-5 row">
						
						<div class="col-md-12 shadow card p-4 bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
							<div class="row">
								<div class="col-12">
									<form class=" form-inline">
										<div class="">
											<select class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" id="numofrecord">
												<option>10</option>
												<option>20</option>
												<option>30</option>
												<option>40</option>
												<option>50</option>
												<option>100</option>
												<option>200</option>
												<option>300</option>
												<option>400</option>
												<option>500</option>
												<option>600</option>
												<option>700</option>
												<option>800</option>
												<option>900</option>
												<option>1000</option>
											</select>
										</div>
										<div class="">
											<select class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" id="order">
												<option value="desc">Descending</option>
												<option value="asc">Ascending</option>
											</select>
										</div>
										<div>
											<input type="text" id="searchitem" placeholder="Search by name or email" class="float-rightmb-2 mr-sm-2 form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>">
											<small id="errorsearch"></small>	
										</div>
										
									</form>
								</div>
							</div>
							<div class="table-responsive" data-example-id="hoverable-table"> 
								<table class="table table-hover text-<?php echo e($text); ?>"> 
									<thead> 
										<tr> 
											<th>Client Name</th>
											<th>Account Balance</th> 
											<th>Email</th> 
											<th>Phone</th>
											<th>Status</th>
											<th>Date registered</th> 
											<th>Action</th> 
										</tr> 
									</thead> 
									<tbody id="userslisttbl"> 
										
									</tbody> 
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<script>
				$('#input1').on('keypress', function(e) {
					return e.which !== 32;
				});
			</script>
	<script>
		function getallusers(){
			let number = document.querySelector('#numofrecord').value;
			let searchvalue = document.querySelector('#searchitem').value;
			let ordervalue = document.querySelector('#order').value;
			let table = document.querySelector('#userslisttbl');
			
			if (searchvalue == "") {
				searchvalue = "query";
			} else {
				searchvalue = searchvalue;
			}

			let url = "<?php echo e(url('/admin/dashboard/getusers/')); ?>" + '/' + number + '/' + searchvalue + '/' + ordervalue;

			fetch(url)
			.then(function(res){
				return res.json();
			})
			.then(function (response){
				if(response.status === 200){
					table.innerHTML = response.data;
					document.querySelector('#searchitem').style.borderColor = '';
				}
				if(response.status === 201){
					table.innerHTML = response.data;
					document.querySelector('#searchitem').style.borderColor = 'red';
				}
			})
			.catch(function(err){
				console.log(err);
			});
			
		}

		let numberopt = document.querySelector('#numofrecord');
		let searchbox = document.querySelector('#searchitem');
		let order = document.querySelector('#order');
		numberopt.addEventListener('change', getallusers);
		order.addEventListener('change', getallusers);
		searchbox.addEventListener('keyup', getallusers);
		getallusers();

		function viewuser(id){
			let url = "<?php echo e(url('/admin/dashboard/user-details/')); ?>" + '/' + id;
			window.location.href = url;
		}
	</script>
	<!-- send all users email -->
	<div id="sendmailModal" class="modal fade" role="dialog">
		<div class="modal-dialog">

		  <!-- Modal content-->
		  <div class="modal-content">
			<div class="modal-header bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
			  <h4 class="modal-title text-<?php echo e($text); ?>">This message will be sent to all your users.</h4>
			  <button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body bg-<?php echo e(Auth('admin')->User()->dashboard_style); ?>">
				  <form method="post" action="<?php echo e(route('sendmailtoall')); ?>">
					<?php echo csrf_field(); ?>
					
					<div class=" form-group">
						<input type="text" name="subject" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" placeholder="Subject" required>
					</div>
					<div class=" form-group">
						<textarea placeholder="Type your message here" class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="message" row="8" placeholder="Type your message here" required></textarea>
					</div>
					<div class=" form-group">
						<input type="submit" class="btn btn-<?php echo e($text); ?>" value="Send">
					</div>
				 </form>
			</div>
		  </div>
		</div>
	  </div>
	  <!-- /send all users email Modal -->
<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Onlinetrade\resources\views/admin/Users/users.blade.php ENDPATH**/ ?>