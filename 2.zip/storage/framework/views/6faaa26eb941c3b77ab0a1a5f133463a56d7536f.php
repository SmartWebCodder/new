<?php
if (Auth::user()->dashboard_style == "light") {
    $bg="light";
    $text = "dark";
} else {
    $bg="dark";
    $text = "light";
}

?>



    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('user.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel bg-<?php echo e($bg); ?>">
            <div class="content bg-<?php echo e($bg); ?>">
                <div class="page-inner">
                    <div class="mt-2 mb-4">
                        <h2 class="text-<?php echo e($text); ?> pb-2">Welcome, <?php echo e(Auth::user()->name); ?>!</h2>
                            <?php if($settings->enable_annoc == "on"): ?>
                                <h5 id="ann" class="text-<?php echo e($text); ?>op-7 mb-4"><?php echo e($settings->newupdate); ?></h5>
                                <?php if(Session::has('getAnouc') && Session::get('getAnouc') == "true" ): ?>
                                    <script type="text/javascript">
                                        var announment = $("#ann").html();
                                        console.log(announment);
                                        swal({
                                            title: "Annoucement!",
                                            text: announment,
                                            icon: "info",
                                            buttons: {
                                                confirm: {
                                                    text: "Okay",
                                                    value: true,
                                                    visible: true,
                                                    className: "btn btn-info",
                                                    closeModal: true
                                                }
                                            }
                                        });
                                    </script>  
                                <?php endif; ?>
                                <?php echo e(session()->forget('getAnouc')); ?>

                            <?php endif; ?>

                    </div>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-secondary">
                                        <i class="fa fa-dollar-sign"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format(Auth::user()->account_bal, 2, '.', ',')); ?></b></h5>
                                        <small class="text-muted">Account Balance</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-success">
                                        <i class="fa fa-coins"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format(Auth::user()->roi, 2, '.', ',')); ?></b></h5>
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Profit</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-secondary">
                                        <i class="fa fa-gift"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format(Auth::user()->bonus, 2, '.', ',')); ?></b></h5>
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Bonus</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-info">
                                        <i class="fa fa-retweet"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format(Auth::user()->ref_bonus, 2, '.', ',')); ?></b></h5>
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Referral Bonus</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-danger">
                                        <i class="fa fa-envelope"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($user_plan->count()); ?></b></h5>
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Investment Plans</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-success">
                                        <i class="fa fa-envelope-open"></i>
                                    </span>
                                    <div>
                                        <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($user_plan_active->count()); ?></b></h5>
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Active Investment Plans</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-warning">
                                        <i class="fa fa-download"></i>
                                    </span>
                                    <div>
                                        <?php $__currentLoopData = $deposited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposited): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($deposited->count)): ?>
                                            <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format($deposited->count, 2, '.', ',')); ?></b></h5>
                                            <?php else: ?>
                                            <h5 class="mb-1 text-<?php echo e($text); ?>"><?php echo e($settings->currency); ?>0.00</h5> 
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Deposit</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="p-3 card bg-<?php echo e($bg); ?> shadow">
                                <div class="d-flex align-items-center">
                                    <span class="mr-3 stamp stamp-md bg-danger">
                                        <i class="fa fa-arrow-alt-circle-up"></i>
                                    </span>
                                    <div>
                                        <?php $__currentLoopData = $deposited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposited): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($deposited->count)): ?>
                                            <h5 class="mb-1 text-<?php echo e($text); ?>"><b><?php echo e($settings->currency); ?><?php echo e(number_format($deposited->count, 2, '.', ',')); ?></b></h5>
                                            <?php else: ?>
                                            <h5 class="mb-1 text-<?php echo e($text); ?>"><?php echo e($settings->currency); ?>0.00</h5> 
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <small class="text-muted text-<?php echo e($text); ?>">Total Withdrawals</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="pt-1 col-12">
                        <h3>Personal Trading Chart</h3>
                        <?php echo $__env->make('includes.chart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                   <div class="container">
                    <div class="row">
        <div class="col-sm-6">
					
					
							<div class="col card p-3 shadow-lg bg-<?php echo e($bg); ?>">
							<div class="accordion accordion-<?php echo e($text); ?> ">
								<form method="post" action="<?php echo e(route('taketrade')); ?>" method="post">
								<!--............................... collapse one -->
								<div class="card">
									<div class="card-header bg-<?php echo e($bgmenu); ?>" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										<div class="span-icon">
											<div class="fa fa-clone">   Trade</div>
										</div>
										
										<div class="span-mode"></div>
									</div>
									<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
										<div class="card-body bg-<?php echo e($bg); ?> shadow">
											<div class="form-group">
												<h5 class="text-<?php echo e($text); ?>">Symbol</h5>
												<select type="text" id="symbol" name="symbol" value="<?php echo e(Auth::user()->sym); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Symbol" required>
                                      <option value="BCH/BTC">BCH/BTC</option>
                        <option value="BCH/EUR">BCH/EUR</option>
                        <option value="BCH/GBP">BCH/GBP</option>
                        <option value="BTC/EOS">BTC/EOS</option>
                        <option value="BTC/EUR">BTC/EUR</option>
                        <option value="BTC/GBP">BTC/GBP</option>
                        <option value="BTC/USD">BTC/USD</option>
                        <option value="BTC/USDC">BTC/USDC</option>
                        <option value="EOS/BTC">EOS/BTC</option>
                        <option value="EOS/EUR">EOS/EUR</option>
                        <option value="EOS/USD">EOS/USD</option>
                        <option value="ETC/BTC">ETC/BTC</option>
                        <option value="ETC/EUR">ETC/EUR</option>
                        <option value="ETC/GBP">ETC/GBP</option>
                        <option value="ETC/USD">ETC/USD</option>
                        <option value="ETH/BTC">ETH/BTC</option>
                        <option value="ETH/EUR">ETH/EUR</option>
                        <option value="ETH/GBP">ETH/GBP</option>
                        <option value="ETH/USD">ETH/USD</option>
                        <option value="LTC/BTC">LTC/BTC</option>
                        <option value="LTC/EUR">LTC/EUR</option>
                        <option value="LTC/GBP">LTC/GBP</option>
                        <option value="LTC/USD">LTC/USD</option>
                        <option value="MKR/BTC">MKR/BTC</option>
                        <option value="PCP/BTC">PCP/BTC</option>
                        <option value="REP/BTC">REP/BTC</option>
                        <option value="REP/USD">REP/USD</option>
                        <option value="TXR/GBP">TXR/GBP</option>
                        <option value="XLM/BTC">XLM/BTC</option>
                        <option value="XLM/EUR">XLM/EUR</option>
                        <option value="XLM/USD">XLM/USD</option>
                        <option value="XRP/BTC">XRP/BTC</option>
                        <option value="XRP/EUR">XRP/EUR</option>
                        <option value="XRP/USD">XRP/USD</option>
                        <option value="ZEC/BTC">ZEC/BTC</option>
                        <option value="ZRX/BTC">ZRX/BTC</option>
                        <option value="ZRX/EUR">ZRX/EUR</option>
                        <option value="ZRX/USD">ZRX/USD</option>
												</select>
											</div>
											<div class="form-group">
												<h5 class="text-<?php echo e($text); ?>">Interval</h5>
												<select type="text" id="time" name="time" value="<?php echo e(Auth::user()->intv); ?>"  class="form-control  text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Interval" required>
										
                       <option value="1-Minute">1 min</option>
                        <option value="3-Minutes">3 min</option>
                        <option value="5-Minutes">5 min</option>
                        <option value="15-Minutes">15 min</option>
                        <option value="30-Minutes">30 min</option>
                        <option value="1-Hour">1 hr</option>
                        <option value="2-Hours">2 hr</option>
                        <option value="1-Day">1 day</option>
												</select>
											</div>
											<div class="form-group">
												<h5 class="text-<?php echo e($text); ?>">Amount</h5>
												<input type="text" value="<?php echo e(Auth::user()->buy); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="100.00" name="amount" required>
											</div>
											
											<div class="form-group">
												<h5 class="text-<?php echo e($text); ?>">Strike Rate</h5>
												<select type="text" id="rate" name="rate" value="<?php echo e(Auth::user()->trade); ?>"  class="form-control  text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Interval" required>
						<option>Choose One....</option>				
                       <option value="Highest_Buy">Highest Buy</option>
                        <option value="High_Buy" >High Buy</option>
                        <option value="Normal">Normal</option>
                        <option value="High_Sell">High Sell</option>
                        <option value="Highest_Sell">Highest Sell</option>
												</select>
											</div>
			 
										</div>
									</div>
								</div>
								 <div class="content">
	<div id="Highest_Buy" class="data">
		<p><b class="buy">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 90 </b> <b class="sell"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 10</b></p> 
		
		
	</div>
	<div id="High_Buy" class="data">
		<b class="buy">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 70 </b> <b class="sell"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 30</b></p>
		
	</div>
	<div id="Normal" class="data">
		<b class="buy">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 50 </b> <b class="sell"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 50</b></p>
		
	</div>
	<div id="High_Sell" class="data">
		<b class="buy">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 30 </b> <b class="sell"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 70</b></p>
	</div>
	<div id="Highest_Sell" class="data">
		<b class="buy">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 10 </b> <b class="sell"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 90</b></p>
	</div>
	
</div>
					 <div style="display: inline-block; height:auto;">
                    <span style="color:rgb(0, 200,  0);" id="buyVal"></span><br>
								&nbsp; &nbsp;<input type="submit" class="btn btn-success" value="Buy">&nbsp;   <i class="fas fa-arrow-up"></i>  &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; 
						</div>
						 <div style="display: inline-block; height:auto;">
                    <span style="color:rgb(0, 200,  0);" id="buyVal"></span><br>
                   
								<input type="submit" class="btn btn-danger" value="sell"> &nbsp; <i class="fas fa-arrow-down"></i>
							</div>
							&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
							<div class="countdown">
	<div class="dat" id="1-Minute"></div>
	<div class="dat" id="3-Minutes"></div>
	<div class="dat" id="5-Minutes"></div>
	<div class="dat" id="15-Minutes"></div>
	<div class="dat" id="30-Minutes"></div>
	<div id="1-Hour" class="dat"><p></p></div>
	<div id="2-Hours" class="dat"><p></p></div>
	<div id="1-Day" class="dat"><p></p></div>
	
	
</div>
								<input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								</form>
</div>
						
								</div>
								
							
						</div>
	<div class="col-sm-6">
					
					        
							<div class="card-body shadow border-danger">
							       <h2 class="text-<?php echo e($text); ?> pb-2">News Update</h2>
							<script src="https://cointelegraph.com/news-widget" data-ct-widget-limit="11" data-ct-widget-theme="dark" data-ct-widget-size="small" data-ct-widget-priceindex="true" data-ct-widget-currency="USD" data-ct-widget-language="en"></script>
								</div>
								
							
						</div>
						
    </div>
                    </div>


                <!-- end of chart -->
            </div>
    <?php $__env->stopSection(); ?>
   
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Onlinetrade\resources\views/user/dashboard.blade.php ENDPATH**/ ?>